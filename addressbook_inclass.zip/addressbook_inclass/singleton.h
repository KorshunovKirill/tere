#pragma once

#include "contact.h"

#include <iostream>
#include <vector>

class Singleton {
public:

	Singleton(const Singleton&) = delete;
	void operator=(const Singleton&) = delete;

	static Singleton& instance() {
		static Singleton inst;
		return inst;
	}

	void add(const Contact& person);
	void sort_list(string _field, bool _sort_order); 
	const void print();

private:

	vector <Contact> list;
	Singleton() {}
	~Singleton() {}
};

