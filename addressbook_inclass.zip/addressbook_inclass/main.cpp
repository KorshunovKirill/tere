#include "contact.h" 
#include "singleton.cpp"

#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;

void main_add() {
	string _name, _surname, _patronymic, _number_phone;
	int _age;
	cout << "Enter contact: " << endl;
	cout << "Name: "; cin >> _name;
	cout << "Surname: "; cin >> _surname;
	cout << "Patronymic: "; cin >> _patronymic;
	cout << "Phone number: "; cin >> _number_phone;
	cout << "Age: "; cin >> _age;
	Contact person(_name, _surname, _patronymic, _number_phone, _age);
	Singleton::instance().add(person);
	cout << "--------------------" << endl;
	cout << "Contact added successfully" << endl;
}

void main_output() {
	cout << "Which field to sort by?" << endl;
	cout << "1.Name" << endl;
	cout << "2.Surname" << endl;
	cout << "3.Patronymic" << endl;
	cout << "4.Phone number" << endl;
	cout << "5.Age" << endl;
	cout << "Enter a number: ";
	int choice_field;
	string selected_field;
	cin >> choice_field;
	switch (choice_field) {
	case 1:
		selected_field = "Name";
		break;
	case 2:
		selected_field = "Surname";
		break;
	case 3:
		selected_field = "Midlename";
		break;
	case 4:
		selected_field = "Phone number";
		break;
	case 5:
		selected_field = "Age";
		break;
	default:
		break;
	}
	cout << selected_field << endl;
	system("clear");
	cout << "How to sort?" << endl;
	cout << "1.Ascending" << endl;
	cout << "2.Descending" << endl;
	cout << "Enter a number: ";
	cin >> choice_field;
	cout << "--------------------" << endl;
	bool _selected_order;
	switch (choice_field) {
	case 1:
		_selected_order = 1;
		break;
	case 2:
		_selected_order = 0;
		break;
	default:
		break;
	}
	Singleton::instance().sort_list(selected_field, _selected_order);
	Singleton::instance().print();
}

int main(int argc, char** argv) {
	while (1) {
		char _choice;
		cout << "Add contact? [y/n]: ";
		cin >> _choice;
		if (_choice == 'y') {
			system("clear");
			main_add();
			continue;
		}
		else
			if (_choice == 'n') {
				system("clear");
				main_output();
				return 0;
			}
			else {
				system("clear");
				cout << "ERROR. Unknown command." << endl;
				continue;
			}
	}
	return 0;
}