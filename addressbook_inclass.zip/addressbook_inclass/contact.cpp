#include "contact.h"

Contact::Contact(const string& name_copy, const string& surname_copy,
	const string& patronymic_copy, const string& number_phone_copy, int age_copy)
{
	_name = name_copy;
	_surname = surname_copy;
	_patronymic = patronymic_copy;
	_number_phone = number_phone_copy;
	_age = age_copy;
}

const string Contact::name() {
	return _name;
};

const string Contact::surname() {
	return _surname;
};

const string Contact::patronymic() {
	return _patronymic;
};

const string Contact::number_phone() {
	return _number_phone;
};

const int Contact::age() {
	return _age;
};

