#pragma once

#include <iostream>
#include <string>

using namespace std;

class Contact 
{
public:

	const string name();
	const string surname();
	const string patronymic();
	const string number_phone();
	const int age();

	Contact(const string& name_copy, const string& surname_copy,
		const string& patronymic_copy, const string& number_phone_copy, int age_copy);

private:

	string  _name;
	string _surname;
	string _patronymic;
	string _number_phone;
	int _age;
};
