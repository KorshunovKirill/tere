#include "singleton.h" 

#include <algorithm>

void Singleton::add(const Contact& person) {
	list.push_back(person);
}

const void Singleton::print() {
	cout << "Count of contacts: "; 
	cout << list.size() << endl;
	for (int i = 0; i < this->list.size(); i++)
	{
		cout << list[i].name() << ' ';
		cout << list[i].surname() << ' ';
		cout << list[i].patronymic() << ' ';
		cout << list[i].number_phone() << ' ';
		cout << list[i].age() << endl;
	}
}

bool order_name_desk(Contact  & a, Contact  & b) {
	return a.name() > b.name();
}

bool order_name_ask(Contact  & a, Contact  & b) {
	return a.name() < b.name();
}

bool order_surname_desk(Contact  & a, Contact  & b) {
	return a.surname() > b.surname();
}

bool order_surname_ask(Contact  & a, Contact  & b) {
	return a.surname() < b.surname();
}

bool order_patronymic_desk(Contact  & a, Contact  & b) {
	return a.patronymic() > b.patronymic();
}

bool order_patronymic_ask(Contact  & a, Contact  & b) {
	return a.patronymic() < b.patronymic();
}

bool order_number_phone_desk(Contact  & a, Contact  & b) {
	return a.number_phone() > b.number_phone();
}

bool order_number_phone_ask(Contact  & a, Contact  & b) {
	return a.number_phone() < b.number_phone();
}

bool order_age_desk(Contact  & a, Contact  & b) {
	return a.age() > b.age();
}


bool order_age_ask(Contact  & a, Contact  & b) {
	return a.age() < b.age();
}


void Singleton::sort_list(string _field, bool _sort_order) {

	if (_field == "Name" && _sort_order)
		sort(list.begin(), list.end(), order_name_ask);

	if (_field == "Name" && !_sort_order)
		sort(list.begin(), list.end(), order_name_desk);

	if (_field == "Surname" && _sort_order)
		sort(list.begin(), list.end(), order_surname_ask);

	if (_field == "Surname" && !_sort_order)
		sort(list.begin(), list.end(), order_surname_desk);

	if (_field == "Patronymic" && _sort_order)
		sort(list.begin(), list.end(), order_patronymic_ask);

	if (_field == "Patronymic" && !_sort_order)
		sort(list.begin(), list.end(), order_patronymic_desk);

	if (_field == "Number Phone" && _sort_order)
		sort(list.begin(), list.end(), order_number_phone_ask);

	if (_field == "Number Phone" && !_sort_order)
		sort(list.begin(), list.end(), order_number_phone_desk);

	if (_field == "Age" && _sort_order)
		sort(list.begin(), list.end(), order_age_ask);

	if (_field == "Age" && !_sort_order)
		sort(list.begin(), list.end(), order_age_desk);
}